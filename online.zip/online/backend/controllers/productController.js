// backend/controllers/productController.js
// Handles all product-related operations — with DB fallback for deployment

const db = require('../config/db');

// ── MOCK PRODUCT DATA (fallback if DB is unavailable) ──────────────────────────
const MOCK_PRODUCTS = [
    { id: 1,  name: 'Samsung Galaxy S23 Ultra',      price: 89999, image: 'https://images.unsplash.com/photo-1610945265064-0e34e5519bbf?w=400', category: 'Electronics', description: 'Flagship smartphone with 200MP camera, S-Pen, and 5000mAh battery.', stock: 50, rating: 4.8, created_at: new Date() },
    { id: 2,  name: 'Apple MacBook Air M2',           price: 114999, image: 'https://images.unsplash.com/photo-1611186871525-6dc8e47bb4f7?w=400', category: 'Electronics', description: 'Supercharged by the Apple M2 chip. 18-hour battery life.', stock: 30, rating: 4.9, created_at: new Date() },
    { id: 3,  name: 'Sony WH-1000XM5 Headphones',    price: 27999, image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400', category: 'Electronics', description: 'Industry-leading noise cancellation with 30 hours battery.', stock: 80, rating: 4.7, created_at: new Date() },
    { id: 4,  name: 'Dell 27" 4K Monitor',            price: 34999, image: 'https://images.unsplash.com/photo-1527443224154-c4a3942d3acf?w=400', category: 'Electronics', description: 'UltraSharp 4K USB-C monitor with 99% sRGB color coverage.', stock: 40, rating: 4.6, created_at: new Date() },
    { id: 5,  name: 'Logitech MX Master 3 Mouse',     price: 8999,  image: 'https://images.unsplash.com/photo-1527814050087-3793815479db?w=400', category: 'Electronics', description: 'Advanced wireless mouse with ultra-fast MagSpeed scrolling.', stock: 120, rating: 4.7, created_at: new Date() },
    { id: 6,  name: 'Nike Air Max 270',               price: 12999, image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400', category: 'Fashion',     description: 'Iconic Nike Air Max cushioning with bold, head-turning style.', stock: 200, rating: 4.5, created_at: new Date() },
    { id: 7,  name: "Levi's 501 Original Jeans",      price: 4999,  image: 'https://images.unsplash.com/photo-1542272604-787c3835535d?w=400', category: 'Fashion',     description: 'The original straight fit jean. 100% cotton denim.', stock: 300, rating: 4.4, created_at: new Date() },
    { id: 8,  name: 'Premium Cotton Kurta Set',       price: 2499,  image: 'https://images.unsplash.com/photo-1594938298603-c8148c4b984b?w=400', category: 'Fashion',     description: 'Elegant ethnic wear crafted from breathable premium cotton.', stock: 150, rating: 4.3, created_at: new Date() },
    { id: 9,  name: 'Ray-Ban Aviator Sunglasses',     price: 6999,  image: 'https://images.unsplash.com/photo-1572635196237-14b3f281503f?w=400', category: 'Fashion',     description: 'Classic aviator style with UV400 protection lenses.', stock: 90, rating: 4.6, created_at: new Date() },
    { id: 10, name: 'Fossil Gen 6 Smartwatch',        price: 18999, image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400', category: 'Fashion',     description: 'Stay connected in style with Wear OS and GPS.', stock: 60, rating: 4.5, created_at: new Date() },
    { id: 11, name: 'Organic Almonds 500g',            price: 699,   image: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?w=400', category: 'Grocery',     description: 'Premium California almonds, rich in protein and healthy fats.', stock: 500, rating: 4.6, created_at: new Date() },
    { id: 12, name: 'Cold Pressed Olive Oil 1L',       price: 899,   image: 'https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?w=400', category: 'Grocery',     description: 'Extra virgin cold-pressed olive oil, rich in antioxidants.', stock: 400, rating: 4.5, created_at: new Date() },
    { id: 13, name: 'Himalayan Pink Salt 1kg',         price: 299,   image: 'https://images.unsplash.com/photo-1587049352846-4a222e784d38?w=400', category: 'Grocery',     description: 'Pure natural pink salt with 84+ minerals.', stock: 600, rating: 4.4, created_at: new Date() },
    { id: 14, name: 'Green Tea 100 Bags',              price: 399,   image: 'https://images.unsplash.com/photo-1627435601361-ec25f5b1d0e5?w=400', category: 'Grocery',     description: 'Premium Darjeeling green tea, boosts metabolism.', stock: 350, rating: 4.7, created_at: new Date() },
    { id: 15, name: 'Mixed Dry Fruits Box 250g',       price: 549,   image: 'https://images.unsplash.com/photo-1599599811080-7f51cca9fc10?w=400', category: 'Grocery',     description: 'Premium cashews, walnuts, pistachios, and raisins.', stock: 450, rating: 4.5, created_at: new Date() },
    { id: 16, name: 'Ergonomic Office Chair',          price: 15999, image: 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=400', category: 'Furniture',    description: 'Premium mesh back chair with lumbar support.', stock: 25, rating: 4.6, created_at: new Date() },
    { id: 17, name: 'Solid Wood Study Table',          price: 12499, image: 'https://images.unsplash.com/photo-1518455027359-f3f8164ba6bd?w=400', category: 'Furniture',    description: 'Crafted from premium sheesham wood with built-in shelf.', stock: 20, rating: 4.5, created_at: new Date() },
    { id: 18, name: '3-Seater Fabric Sofa',            price: 34999, image: 'https://images.unsplash.com/photo-1493663284031-b7e3aefcae8e?w=400', category: 'Furniture',    description: 'Modern 3-seater sofa with premium fabric upholstery.', stock: 15, rating: 4.4, created_at: new Date() },
    { id: 19, name: 'Minimalist Bookshelf',            price: 7999,  image: 'https://images.unsplash.com/photo-1594620302200-9a762244a156?w=400', category: 'Furniture',    description: '5-tier industrial bookshelf, holds up to 50kg.', stock: 35, rating: 4.3, created_at: new Date() },
    { id: 20, name: 'King Size Platform Bed',          price: 29999, image: 'https://images.unsplash.com/photo-1631049307264-da0ec9d70304?w=400', category: 'Furniture',    description: 'Solid wood king size bed with hydraulic storage box.', stock: 10, rating: 4.7, created_at: new Date() },
    { id: 21, name: 'Lakme 9to5 Foundation',           price: 599,   image: 'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?w=400', category: 'Beauty',      description: 'Lightweight foundation with SPF 35, 16-hour wear.', stock: 250, rating: 4.4, created_at: new Date() },
    { id: 22, name: 'Biotique Bio Sunscreen SPF 50',   price: 349,   image: 'https://images.unsplash.com/photo-1598440947619-2c35fc9aa908?w=400', category: 'Beauty',      description: 'Natural botanical sunscreen, water-resistant formula.', stock: 300, rating: 4.3, created_at: new Date() },
    { id: 23, name: 'The Body Shop Shea Butter',       price: 1299,  image: 'https://images.unsplash.com/photo-1556228720-195a672e8a03?w=400', category: 'Beauty',      description: 'Intensely moisturizing body butter with shea butter.', stock: 180, rating: 4.6, created_at: new Date() },
    { id: 24, name: 'Maybelline Lip Color Kit',        price: 799,   image: 'https://images.unsplash.com/photo-1586495777744-4e6232bf2253?w=400', category: 'Beauty',      description: 'Long-lasting liquid lip color, 12-hour wear, 6 shades.', stock: 220, rating: 4.5, created_at: new Date() },
    { id: 25, name: 'Vitamin C Serum 30ml',            price: 999,   image: 'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?w=400', category: 'Beauty',      description: '20% Vitamin C + Hyaluronic Acid, brightens skin.', stock: 200, rating: 4.7, created_at: new Date() },
];

// ── Helper: filter mock data ────────────────────────────────────────────────────
function filterMock(category, search, limit, offset) {
    let data = [...MOCK_PRODUCTS];
    if (category && category !== 'All') data = data.filter(p => p.category === category);
    if (search) {
        const q = search.toLowerCase();
        data = data.filter(p => p.name.toLowerCase().includes(q) || p.description.toLowerCase().includes(q));
    }
    const total = data.length;
    data = data.slice(parseInt(offset), parseInt(offset) + parseInt(limit));
    return { data, total };
}

// ── GET ALL PRODUCTS (with optional category filter & search) ─────────────────
const getProducts = async (req, res) => {
    try {
        const { category, search, limit = 20, offset = 0 } = req.query;
        let query  = 'SELECT * FROM products WHERE 1=1';
        const params = [];

        if (category && category !== 'All') {
            query += ' AND category = ?';
            params.push(category);
        }
        if (search) {
            query += ' AND (name LIKE ? OR description LIKE ?)';
            params.push(`%${search}%`, `%${search}%`);
        }
        query += ' ORDER BY created_at DESC LIMIT ? OFFSET ?';
        params.push(parseInt(limit), parseInt(offset));

        const [products] = await db.query(query, params);

        let countQuery = 'SELECT COUNT(*) as total FROM products WHERE 1=1';
        const countParams = [];
        if (category && category !== 'All') { countQuery += ' AND category = ?'; countParams.push(category); }
        if (search) { countQuery += ' AND (name LIKE ? OR description LIKE ?)'; countParams.push(`%${search}%`, `%${search}%`); }
        const [[{ total }]] = await db.query(countQuery, countParams);

        res.json({ success: true, products, total, limit: parseInt(limit), offset: parseInt(offset) });

    } catch (err) {
        // ── DB unavailable → serve mock data ──
        console.warn('DB unavailable, serving mock products:', err.message);
        const { category, search, limit = 20, offset = 0 } = req.query;
        const { data, total } = filterMock(category, search, limit, offset);
        res.json({ success: true, products: data, total, limit: parseInt(limit), offset: parseInt(offset), _source: 'mock' });
    }
};

// ── GET SINGLE PRODUCT ────────────────────────────────────────────────────────
const getProductById = async (req, res) => {
    try {
        const [products] = await db.query('SELECT * FROM products WHERE id = ?', [req.params.id]);
        if (products.length === 0) {
            return res.status(404).json({ success: false, message: 'Product not found.' });
        }
        res.json({ success: true, product: products[0] });
    } catch (err) {
        // ── DB unavailable → serve mock product ──
        console.warn('DB unavailable, serving mock product:', err.message);
        const product = MOCK_PRODUCTS.find(p => p.id === parseInt(req.params.id));
        if (!product) return res.status(404).json({ success: false, message: 'Product not found.' });
        res.json({ success: true, product, _source: 'mock' });
    }
};

// ── GET FEATURED PRODUCTS ─────────────────────────────────────────────────────
const getFeaturedProducts = async (req, res) => {
    try {
        const [products] = await db.query('SELECT * FROM products ORDER BY rating DESC LIMIT 8');
        res.json({ success: true, products });
    } catch (err) {
        // ── DB unavailable → serve mock featured ──
        console.warn('DB unavailable, serving mock featured:', err.message);
        const products = [...MOCK_PRODUCTS].sort((a, b) => b.rating - a.rating).slice(0, 8);
        res.json({ success: true, products, _source: 'mock' });
    }
};

// ── GET CATEGORIES ─────────────────────────────────────────────────────────────
const getCategories = async (req, res) => {
    try {
        const [rows] = await db.query('SELECT category, COUNT(*) as count FROM products GROUP BY category');
        res.json({ success: true, categories: rows });
    } catch (err) {
        // ── DB unavailable → serve mock categories ──
        console.warn('DB unavailable, serving mock categories:', err.message);
        const counts = {};
        MOCK_PRODUCTS.forEach(p => { counts[p.category] = (counts[p.category] || 0) + 1; });
        const categories = Object.entries(counts).map(([category, count]) => ({ category, count }));
        res.json({ success: true, categories, _source: 'mock' });
    }
};

module.exports = { getProducts, getProductById, getFeaturedProducts, getCategories };
