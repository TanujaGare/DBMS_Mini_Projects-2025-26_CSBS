// backend/routes/adminRoutes.js
const express = require('express');
const router  = express.Router();
const db      = require('../config/db');
const { authenticateToken, isAdmin } = require('../middleware/auth');

// All admin routes require login + admin role
router.use(authenticateToken, isAdmin);

// ── DASHBOARD STATS ──────────────────────────────────────────────────────────
router.get('/stats', async (req, res) => {
    try {
        const [[{ totalUsers }]]    = await db.query('SELECT COUNT(*) AS totalUsers FROM users WHERE role = "user"');
        const [[{ totalProducts }]] = await db.query('SELECT COUNT(*) AS totalProducts FROM products');
        const [[{ totalOrders }]]   = await db.query('SELECT COUNT(*) AS totalOrders FROM orders');
        const [[{ totalRevenue }]]  = await db.query('SELECT IFNULL(SUM(total_price),0) AS totalRevenue FROM orders WHERE status != "Cancelled"');
        const [recentOrders]        = await db.query(
            'SELECT o.id, u.name AS user_name, o.total_price, o.status, o.order_date FROM orders o JOIN users u ON o.user_id = u.id ORDER BY o.order_date DESC LIMIT 5'
        );
        res.json({ success: true, stats: { totalUsers, totalProducts, totalOrders, totalRevenue }, recentOrders });
    } catch (err) {
        console.error('Admin stats error:', err);
        res.status(500).json({ success: false, message: 'Server error.' });
    }
});

// ── USERS ─────────────────────────────────────────────────────────────────────
router.get('/users', async (req, res) => {
    try {
        const [users] = await db.query('SELECT id, name, email, phone, role, created_at FROM users ORDER BY created_at DESC');
        res.json({ success: true, users });
    } catch (err) {
        res.status(500).json({ success: false, message: 'Server error.' });
    }
});

router.delete('/users/:id', async (req, res) => {
    try {
        const [u] = await db.query('SELECT role FROM users WHERE id = ?', [req.params.id]);
        if (!u.length) return res.status(404).json({ success: false, message: 'User not found.' });
        if (u[0].role === 'admin') return res.status(400).json({ success: false, message: 'Cannot delete admin account.' });
        await db.query('DELETE FROM users WHERE id = ?', [req.params.id]);
        res.json({ success: true, message: 'User deleted.' });
    } catch (err) {
        res.status(500).json({ success: false, message: 'Server error.' });
    }
});

// ── PRODUCTS ──────────────────────────────────────────────────────────────────
router.get('/products', async (req, res) => {
    try {
        const [products] = await db.query('SELECT * FROM products ORDER BY created_at DESC');
        res.json({ success: true, products });
    } catch (err) {
        res.status(500).json({ success: false, message: 'Server error.' });
    }
});

router.post('/products', async (req, res) => {
    try {
        const { name, price, image, category, description, stock, rating } = req.body;
        if (!name || !price || !category) return res.status(400).json({ success: false, message: 'Name, price, category required.' });
        const [result] = await db.query(
            'INSERT INTO products (name, price, image, category, description, stock, rating) VALUES (?, ?, ?, ?, ?, ?, ?)',
            [name, price, image || '', category, description || '', stock || 100, rating || 4.0]
        );
        res.status(201).json({ success: true, message: 'Product added.', id: result.insertId });
    } catch (err) {
        res.status(500).json({ success: false, message: 'Server error.' });
    }
});

router.put('/products/:id', async (req, res) => {
    try {
        const { name, price, image, category, description, stock, rating } = req.body;
        await db.query(
            'UPDATE products SET name=?, price=?, image=?, category=?, description=?, stock=?, rating=? WHERE id=?',
            [name, price, image, category, description, stock, rating, req.params.id]
        );
        res.json({ success: true, message: 'Product updated.' });
    } catch (err) {
        res.status(500).json({ success: false, message: 'Server error.' });
    }
});

router.delete('/products/:id', async (req, res) => {
    try {
        await db.query('DELETE FROM products WHERE id = ?', [req.params.id]);
        res.json({ success: true, message: 'Product deleted.' });
    } catch (err) {
        res.status(500).json({ success: false, message: 'Server error.' });
    }
});

// ── ORDERS ────────────────────────────────────────────────────────────────────
router.get('/orders', async (req, res) => {
    try {
        const [orders] = await db.query(
            'SELECT o.*, u.name AS user_name, u.email AS user_email FROM orders o JOIN users u ON o.user_id = u.id ORDER BY o.order_date DESC'
        );
        res.json({ success: true, orders });
    } catch (err) {
        res.status(500).json({ success: false, message: 'Server error.' });
    }
});

router.put('/orders/:id/status', async (req, res) => {
    try {
        const { status } = req.body;
        const validStatuses = ['Pending', 'Processing', 'Shipped', 'Delivered', 'Cancelled'];
        if (!validStatuses.includes(status)) return res.status(400).json({ success: false, message: 'Invalid status.' });
        await db.query('UPDATE orders SET status = ? WHERE id = ?', [status, req.params.id]);
        res.json({ success: true, message: 'Order status updated.' });
    } catch (err) {
        res.status(500).json({ success: false, message: 'Server error.' });
    }
});

module.exports = router;
