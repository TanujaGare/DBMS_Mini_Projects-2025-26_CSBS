// Script to add the admin user to your existing database
// Run: node backend/setup-admin.js  (from the 'online' folder)
// OR:  node setup-admin.js          (from inside 'backend' folder)

const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '.env') });

const bcrypt = require('bcryptjs');
const mysql  = require('mysql2/promise');

async function setupAdmin() {
    let conn;
    try {
        console.log('Connecting to MySQL...');
        conn = await mysql.createConnection({
            host:     process.env.DB_HOST     || '127.0.0.1',
            user:     process.env.DB_USER     || 'root',
            password: process.env.DB_PASSWORD || '',
            database: process.env.DB_NAME     || 'online_shopping',
            port:     parseInt(process.env.DB_PORT) || 3306,
        });
        console.log('✅ MySQL connected!');

        // 1. Add role column if not exists
        try {
            await conn.query("ALTER TABLE users ADD COLUMN role ENUM('user','admin') DEFAULT 'user'");
            console.log('✅ Added role column to users table.');
        } catch (e) {
            if (e.code === 'ER_DUP_FIELDNAME') {
                console.log('ℹ️  Role column already exists.');
            } else {
                console.warn('⚠️  Role column warning:', e.message);
            }
        }

        // 2. Hash the admin password
        console.log('Hashing password (this may take a moment)...');
        const hashedPassword = await bcrypt.hash('Admin@123', 10);
        console.log('✅ Password hashed.');

        // 3. Insert or update admin user
        const [existing] = await conn.query('SELECT id FROM users WHERE email = ?', ['admin@shopeasy.com']);
        if (existing.length > 0) {
            await conn.query(
                'UPDATE users SET name=?, password=?, phone=?, role=? WHERE email=?',
                ['Admin', hashedPassword, '+91 98765 00000', 'admin', 'admin@shopeasy.com']
            );
            console.log('✅ Admin user updated.');
        } else {
            await conn.query(
                'INSERT INTO users (name, email, password, phone, role) VALUES (?, ?, ?, ?, ?)',
                ['Admin', 'admin@shopeasy.com', hashedPassword, '+91 98765 00000', 'admin']
            );
            console.log('✅ Admin user created.');
        }

        console.log('\n╔═══════════════════════════════════════╗');
        console.log('║        Admin Login Credentials        ║');
        console.log('╠═══════════════════════════════════════╣');
        console.log('║  Email:    admin@shopeasy.com         ║');
        console.log('║  Password: Admin@123                  ║');
        console.log('║  URL:      /admin.html                ║');
        console.log('╚═══════════════════════════════════════╝\n');

        await conn.end();
        process.exit(0);
    } catch (err) {
        console.error('❌ Error:', err.message);
        if (conn) await conn.end().catch(() => {});
        process.exit(1);
    }
}

setupAdmin();

